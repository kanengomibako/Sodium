#ifndef USER_MAIN_HPP
#define USER_MAIN_HPP

void mainInit();

void mainLoop();

void fxChange();

void loadData();
void saveData();
void eraseData();

#endif // USER_MAIN_HPP
