#ifndef _TUNER_HPP
#define _TUNER_HPP

#include "common.h"

void tunerDisp();

void tunerProcess(float xL[], float xR[]);

#endif // _TUNER_HPP
